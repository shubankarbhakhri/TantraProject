package com.example.tantraproject;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {


    public void speechinput(View v){
        Intent i = new Intent((RecognizerIntent.ACTION_RECOGNIZE_SPEECH));
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        if(i.resolveActivity(getPackageManager())!=null)
        {
            startActivityForResult(i,10);
        }
        else
        {
            Toast.makeText(this,"your device don't support speech language",Toast.LENGTH_SHORT).show();
        }

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch(requestCode)
        {
            case 10:
                if (resultCode == RESULT_OK && data != null) {
                    ArrayList input = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    TextView t1 = (TextView) findViewById(R.id.textView);
                    t1.setText((CharSequence) input.get(0));
                    t1.animate().alpha(1).setDuration(1000);
                    TextView t2 = findViewById(R.id.textView);
                    String t= (String) t2.getText().toString().toLowerCase();
                    String x="";

                    if(t.equalsIgnoreCase("instagram")){
                        Intent i2 = new Intent(Intent.ACTION_MAIN);
                        PackageManager managerclock = getPackageManager();
                        i2 = managerclock.getLaunchIntentForPackage("com." + t +".android");
                        i2.addCategory(Intent.CATEGORY_LAUNCHER);
                        startActivity(i2);
                    }
                    if(t.equalsIgnoreCase("snapchat")){
                        Intent i2 = new Intent(Intent.ACTION_MAIN);
                        PackageManager managerclock = getPackageManager();
                        i2 = managerclock.getLaunchIntentForPackage("com." + t +".android");
                        i2.addCategory(Intent.CATEGORY_LAUNCHER);
                        startActivity(i2);
                    }
                    if(t.equalsIgnoreCase("facebook")){
                        Intent i2 = new Intent(Intent.ACTION_MAIN);
                        PackageManager managerclock = getPackageManager();
                        i2 = managerclock.getLaunchIntentForPackage("com." + t +".katana");
                        i2.addCategory(Intent.CATEGORY_LAUNCHER);
                        startActivity(i2);
                    }
                    if(t.equalsIgnoreCase("whatsapp")){
                        Intent i2 = new Intent(Intent.ACTION_MAIN);
                        PackageManager managerclock = getPackageManager();
                        i2 = managerclock.getLaunchIntentForPackage("com." + t);
                        i2.addCategory(Intent.CATEGORY_LAUNCHER);
                        startActivity(i2);
                    }
                    if(t.equalsIgnoreCase("camera")){
                        Intent i2 = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                        //PackageManager managerclock = getPackageManager();
                        //i2 = managerclock.getLaunchIntentForPackage("com." + t);
                        //i2.addCategory(Intent.CATEGORY_LAUNCHER);
                        startActivity(i2);
                    }

                }
                break;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    }

